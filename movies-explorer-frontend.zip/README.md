# movies-explorer-frontend
## макет light-1

### ссылка на фронт https://movies-artur.nomoreparties.co
### ссылка на бэк https://api.movies-artur.nomoreparties.co
### ссылка на фронт(git) https://github.com/Burbon85/movies-explorer-frontend ветка level-3
### ссылка на бэк(git) https://github.com/Burbon85/movies-explorer-api/tree/level-1

#### Ссылка на пулреквест https://github.com/Burbon85/movies-explorer-frontend/pull/5