export const FILM_BASE_URL = 'https://api.nomoreparties.co';
export const MOVIES_URL = 'https://api.nomoreparties.co/beatfilm-movies';
export const BASE_URL = 'https://api.movies-artur.nomoreparties.co';