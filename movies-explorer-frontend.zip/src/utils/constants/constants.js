export const WINDOW_WIDTH_1020 = 1020;
export const WINDOW_WIDTH_690 = 690;
export const MOVIES_12_FILMS = 12;
export const MOVIES_8_FILMS = 8;
export const MOVIES_5_FILMS = 5;
export const MOVIES_3_MORE_FILMS = 3;
export const MOVIES_2_MORE_FILMS = 2;
export const SHORT_FILMS = 40;